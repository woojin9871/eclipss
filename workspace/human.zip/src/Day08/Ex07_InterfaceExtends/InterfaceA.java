package Day08.Ex07_InterfaceExtends;

public interface InterfaceA {

	public void methodA();
}
