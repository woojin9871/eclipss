package Day08.Ex07_InterfaceExtends;

public interface InterfaceB {

	public void methodB();
}
