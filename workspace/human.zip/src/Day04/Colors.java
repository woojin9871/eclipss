package Day04;

public enum Colors {
	CORNFLOWERBLUE, ROYALBLUE, COBALRBLE, SKYBLUE

}
