package Day01;

public class Ex03_Int {
	public static void main(String[] args) {
		
		// 리터럴
		// : 프로그램에서 직접 표현하는 값
		
		// 10진수
		int var1 = 10;
		System.out.println(var1);
		
		//8진수
		int var2 = 010;
		System.out.println(var2);
		
		//16진수
		int var3 = 0x10;
		System.out.println(var3);
		
		
	}
}
