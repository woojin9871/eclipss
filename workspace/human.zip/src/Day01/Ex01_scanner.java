package Day01;

import java.util.Scanner;

public class Ex01_scanner {

	//main : ctri + space
	public static void main(String[]arge) {
		//[클래스 타입] 객체명 = new [클래스명]();
	    // Scanner 객체 생성
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 입력 : ");
		System.out.println( sc.nextInt() );
	
	sc.close();
		
	

	}
	
	
}