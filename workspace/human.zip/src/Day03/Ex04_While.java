package Day03;

public class Ex04_While {
	
	public static void main(String[] args) {
		// 1~20까지 공백을 두고 출력하시오.
		int a = 1;
				
		// 조건?
		while( a <= 20 ) {
			System.out.println(a);
			a++;
			
			
		}
		
	}
}
